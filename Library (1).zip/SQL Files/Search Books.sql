Select
	*
FROM
	library.books	