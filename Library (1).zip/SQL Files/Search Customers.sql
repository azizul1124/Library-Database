select 
	* 
FROM 
	library.customers