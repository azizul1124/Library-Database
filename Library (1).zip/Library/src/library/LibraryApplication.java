package library;

import java.util.Scanner;

public class LibraryApplication {

	static Scanner input;
	static Database database;

	public static void main(String[] args) {

		input = new Scanner(System.in);
		boolean loop = true;
		database = new Database();
		Database.createTables();

		while (loop) {
			System.out.println();
			System.out.print("Enter command (enter 'h' for help): ");
			String choice = input.nextLine();
			System.out.println();

			switch (choice) {
			case "h":

				System.out.println("1: show books");
				System.out.println("2: show customers");
				System.out.println("3: add books");
				System.out.println("4: edit books");
				System.out.println("5: delete books");
				System.out.println("6: add customer");
				System.out.println("7: edit customer");
				System.out.println("8: delete customer");
				System.out.println("9: search Customer");
				System.out.println("exit: exit the program");

				break;

			case "1":
				getBook();
				break;

			case "2":
				getCustomers();
				break;

			case "3":
				addBook();
				break;

			case "4":
				editBook();
				break;

			case "5":
				deleteBook();
				break;

			case "6":
				addCustomer();
				break;

			case "7":
				editCustomer();
				break;

			case "8":
				deleteCustomer();
				break;

			case "9":
				searchCustomer();
				break;

			case "exit":
				System.out.println("Goodbye");
				loop = false;
				break;

			}
		}

	}

	public static void getBook() {
		try {
			Database.getBooks();
		} catch (Exception e) {

			System.out.println(e);
		}
	}

	public static void getCustomers() {
		try {
			Database.getCustomers();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
// Add Books==============================================

	public static void addBook() {

		System.out.println("Enter Title");
		String title = input.nextLine();

		System.out.println("Enter Author");
		String author = input.nextLine();

		System.out.println("Enter Genre");
		String genre = input.nextLine();

		System.out.println("Enter the Number of Copies");
		int numberOfCopies = input.nextInt();

		Book newBook = new Book(title, author, genre, numberOfCopies);

		Database.addBook(newBook);

	}

//Add Customer==============================================

	public static void addCustomer() {

		System.out.println("Enter Customer First Name");
		String first = input.nextLine();

		System.out.println("Enter Customer Last Name");
		String last = input.nextLine();

		System.out.println("Enter Customer Phone Number");
		String phone = input.nextLine();

		System.out.println("Enter Customer Address");
		String address = input.nextLine();

		Customer newCustomer = new Customer(first, last, phone, address);

		Database.addCustomer(newCustomer);

	}

	public static void deleteBook() {
		System.out.println("Enter the title of book: ");
		String book = input.nextLine();
		Database.deleteBook(book);
		System.out.print(book + " has been deleted");
	}

	public static void deleteCustomer() {
		System.out.println("Enter the customer last name: ");
		String customer = input.nextLine();
		Database.deleteCustomer(customer);
	}

	public static void editBook() {
		System.out.println("Enter the title of book");
		String title = input.nextLine();
		System.out.println("Enter new title");
		String newTitle = input.nextLine();
		System.out.println("Enter new author");
		String newAuthor = input.nextLine();
		System.out.println("Enter new genre");
		String newGenre = input.nextLine();
		System.out.println("Enter number of copies");
		int newNumCopies = input.nextInt();

		Database.editBook(title, newTitle, newAuthor, newGenre, newNumCopies);
	}

	public static void editCustomer() {
		System.out.println("Enter customer last name");
		String lastName = input.nextLine();
		System.out.println("Enter new first name");
		String newFirstName = input.nextLine();
		System.out.println("Enter new last name");
		String newLastName = input.nextLine();
		System.out.println("Enter new phone");
		String newPhone = input.nextLine();
		System.out.println("Enter new address");
		String newAddress = input.nextLine();

		Database.editCustomer(lastName, newFirstName, newLastName, newPhone, newAddress);
	}

	public static void searchCustomer() {
		System.out.println("Enter customer ID");
		int id = input.nextInt();
		
		try {
			Database.getCustomer(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
