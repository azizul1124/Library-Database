package library;

import java.util.ArrayList;

public class Library {

	
	public ArrayList<Book> books = new ArrayList<>();
	public ArrayList<Customer> customer = new ArrayList<>();
	
	public Library() {
		
		books.add(new Book("Game of Thrones", "George Martin", "Drama", 5));
		books.add(new Book("Interview With A Vampire", "Ann Rice", "Thriller", 3));
		books.add(new Book("Find Your Why", "Simon Sinek", "Motivational", 4));
		books.add(new Book("Harry Potter", "J. K. Rowling", "Fantasy", 10));
		books.add(new Book("Clean Code", "Robert Martin", "Insructional", 6));
		
		customer.add(new Customer("mike", "flasco", "3053331081", "123 orlando ave"));
		
	}
}
