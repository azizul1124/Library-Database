package library;

public class Book {
	
	public String title;
	public String author;
	public String genre;
	public int numberOfCopies;
	

	public Book(String title,String author, String genre, int numberOfCopies){
		this.title = title;
		this.author = author;
		this.genre = genre;
		this.numberOfCopies = numberOfCopies;
	}
	
	public String toString() {
		return "Book Title " + title + " Genre " + genre + " Number of Copies " + numberOfCopies;
	}
	
}
