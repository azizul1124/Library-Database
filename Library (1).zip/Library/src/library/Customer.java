package library;

public class Customer {
	
	public String first;
	public String last;
	public String phone;
	public String address;
	
	public Customer(String first, String last, String phone, String address) {
		this.first = first;
		this.last = last;
		this.phone = phone;
		this.address = address;
	}
	
	public String toString() {
		return "First Name: " + first + " Last Name: " + last + " Phone Number: " + phone + " Address: " + address;
	}
}
