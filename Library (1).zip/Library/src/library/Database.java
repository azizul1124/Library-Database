package library;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Database {

	static Connection conn;
	static Library library;

// Make connection to database ===================================================================================================
	public static Connection getConnection() throws Exception {

		try {
			String driver = "com.mysql.jdbc.Driver";
			String url = "jdbc:mysql://localhost:3306/library";
			String username = "root";
			String password = "root";

			Class.forName(driver);

			conn = DriverManager.getConnection(url, username, password);
			System.out.println("Connected");

			return conn;

		} catch (Exception e) {
			System.out.println(e);
		}

		return null;
	}

// Create database tables ========================================================================================================
	public static void createTables() {
		try {
			Connection conn = getConnection();
			PreparedStatement create = conn
					.prepareStatement("CREATE TABLE IF NOT EXISTS books(" + "bookID int NOT NULL AUTO_INCREMENT,"
							 + "title varchar(255)," + "author varchar(255)," + "genre varchar(255),"
							+ "number_of_copies INTEGER," + "PRIMARY KEY(bookID))");
			create.executeUpdate();

		} catch (Exception e) {

			System.out.println(e);
		} finally {

		}
		try {
			PreparedStatement create = conn.prepareStatement("CREATE TABLE IF NOT EXISTS customers("
					+ "customerID int NOT NULL AUTO_INCREMENT," + "firstName varchar(255)," + "lastName varchar(255),"
					+ "address varchar(255)," + "phone varchar(255)," + "PRIMARY KEY(customerID))");
			create.executeUpdate();

		} catch (Exception e) {

			System.out.println(e);
		} finally {

		}
	}

// Retrieve list of books from database ==========================================================================================
	public static ArrayList<String> getBooks() throws Exception {
		try {

			PreparedStatement statement = conn.prepareStatement("SELECT * FROM books");

			ResultSet result = statement.executeQuery();
			int count = 0;



			System.out.println("Books");
			System.out.println("====================================");
			while (result.next()) {
				System.out.println("Book ID: " + result.getString("bookID"));
				System.out.println("title: " + result.getString("title"));
				System.out.println("Author: " + result.getString("author"));
				System.out.println("Genre: " + result.getString("genre"));
				System.out.println("Number Of Copies: " + result.getString("number_of_Copies"));
				System.out.println("===================================");

				count++;
			}

			System.out.println("All Records Have Been Selected");
			System.out.println(count);

			return null;

		} catch (Exception e) {
			System.out.println(e);
			return null;
		}

	}

	// Retrieve list of customers =================================================================================================

	public static ArrayList<String> getCustomers() throws Exception {
		try {

			PreparedStatement statement = conn.prepareStatement("SELECT * FROM customers");

			ResultSet result = statement.executeQuery();
			int count = 0;

			System.out.println("Customers");
			System.out.println("====================================");
			while (result.next()) {

				System.out.println("Customer ID: " + result.getString("CustomerID"));
				System.out.println("First Name: " + result.getString("firstName"));
				System.out.println("Last Name: " + result.getString("LastName"));
				System.out.println("Phone Number: " + result.getString("phone"));
				System.out.println("Address: " + result.getString("address"));
				System.out.println("===================================");

				count++;
			}

			System.out.println(count + " records found");

			return null;

		} catch (Exception e) {
			System.out.println(e);
			return null;
		}

	}

// Get specific customer ==========================================================================================================
	public static ArrayList<String> getCustomer(int id) throws Exception {
		try {

			PreparedStatement statement = conn.prepareStatement("SELECT * FROM customers WHERE customerID = " + id);

			ResultSet result = statement.executeQuery();

			System.out.println("Customer Information ");
			System.out.println("====================================");

			while (result.next()) {
				System.out.println("Customer ID: " + result.getString("customerID"));
				System.out.println("First Name: " + result.getString("firstName"));
				System.out.println("Last Name: " + result.getString("LastName"));
				System.out.println("Phone Number: " + result.getString("phone"));
				System.out.println("Address: " + result.getString("address"));
				System.out.println("===================================");

			}

			return null;

		} catch (Exception e) {
			System.out.println(e);
			return null;
		}

	}

// Add book to database ==========================================================================================================
	public static void addBook(Book book) {

		library = new Library();

		try {
			Connection conn = getConnection();
			PreparedStatement addBooks = conn.prepareStatement(
					"INSERT INTO books(title, author, genre, number_of_Copies)" + " values ('" + book.title + "', '"
							+ book.author + "', '" + book.genre + "', '" + book.numberOfCopies + "' )");
			addBooks.executeUpdate();

		} catch (Exception e) {
			System.out.println(e);
		}

		finally {
			System.out.println("Book Added");
		}

	}

// Add customer to database ======================================================================================================

	public static void addCustomer(Customer customer) {

		library = new Library();

		try {
			Connection conn = getConnection();
			PreparedStatement addCustomers = conn.prepareStatement(
					"INSERT INTO customers(firstName, lastName, phone, address)" + " values ('" + customer.first
							+ "', '" + customer.last + "', '" + customer.phone + "', '" + customer.address + "' )");
			addCustomers.executeUpdate();

		} catch (Exception e) {
			System.out.println(e);
		}

		finally {
			System.out.println("Customer Added");
		}

	}

// Delete book from database======================================================================================================
	public static void deleteBook(String input) {

		try {
			String sql = "DELETE FROM books WHERE title = '" + input + "' ";
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(sql);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

// Delete customer from database==================================================================================================
	public static void deleteCustomer(String input) {

		try {
			String sql = "DELETE FROM customers WHERE LastName = '" + input + "' ";
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(sql);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("All Records Have Been Selected");
	}

// Edit book in database =========================================================================================================

	public static void editBook(String book, String newTitle, String newAuthor, String newGenre, int newNumCopies) {

		try {
			PreparedStatement update = conn.prepareStatement(
					"UPDATE books SET title = ?, author = ?, genre = ?, number_of_copies = ? WHERE title = ?");
			update.setString(1, newTitle);
			update.setString(2, newAuthor);
			update.setString(3, newGenre);
			update.setInt(4, newNumCopies);
			update.setString(5, book);
			update.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}

		System.out.println("Records Have Been updated");

	}

// Edit customer in database =========================================================================================================

	public static void editCustomer(String lastName, String newFirstName, String newLastName, String newPhone,
			String newAddress) {

		try {
			PreparedStatement update = conn.prepareStatement(
					"UPDATE customers SET firstName = ?, lastName = ?, phone = ?, address = ? WHERE lastName = ?");
			update.setString(1, newFirstName);
			update.setString(2, newLastName);
			update.setString(3, newPhone);
			update.setString(4, newAddress);
			update.setString(5, lastName);
			update.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}

		System.out.println("Customer records Have Been updated");
	}
}
